package com.example.demo;

public class Validator {
	
	private String validation;
	private String failueMessage;
	public String getValidation() {
		return validation;
	}
	public void setValidation(String validation) {
		this.validation = validation;
	}
	public String getFailueMessage() {
		return failueMessage;
	}
	public void setFailueMessage(String failueMessage) {
		this.failueMessage = failueMessage;
	}

	
}
