package com.example.demo;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootApplication
public class JsonpocApplication {

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		SpringApplication.run(JsonpocApplication.class, args);
		demo();
	}
	
	/*public static void demo() throws JsonParseException, JsonMappingException, IOException {
		Map<String, Config> configs = new HashMap<>();
		ObjectMapper mapper = new ObjectMapper();
		File folder = new File("json");
		for(String fileName: folder.list()) {
			File file = new File("json/" + fileName);
			if (file.isFile()) {
				Config cfg = mapper.readValue(file, Config.class);
				configs.put(file.getName(), cfg);
			}
		}
		
		
		*/
	
	public static Config getConfig(String filePath) throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
			File file = new File(filePath);
			if (file.isFile()) {
				return mapper.readValue(file, Config.class);
			}
		return null;
	}
	
	public static void demo() throws JsonParseException, JsonMappingException, IOException {
		Map<String, Config> configs = new HashMap<>();
		ObjectMapper mapper = new ObjectMapper();
		File folder = new File("json");
		for(String fileName: folder.list()) {
			File file = new File("json/" + fileName);
			if (file.isFile()) {
				Config cfg = mapper.readValue(file, Config.class);
				configs.put(file.getName(), cfg);
			}
		}
		System.out.println(configs.containsKey("demo33.json"));
		
		/*JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader("json/demo.json"));
 
			// A JSON object. Key value pairs are unordered. JSONObject supports java.util.Map interface.
			JSONObject jsonObject = (JSONObject) obj;
			String name=(String) jsonObject.get("Name");
			String author=(String) jsonObject.get("Author");	
			
			System.out.println("Name :: "+name);

			System.out.println("Author :: "+author);
			// A JSON array. JSONObject supports java.util.List interface.
			JSONArray companyList = (JSONArray) jsonObject.get("Company List");
 
			// An iterator over a collection. Iterator takes the place of Enumeration in the Java Collections Framework.
			// Iterators differ from enumerations in two ways:
			// 1. Iterators allow the caller to remove elements from the underlying collection during the iteration with well-defined semantics.
			// 2. Method names have been improved.
			Iterator<JSONObject> iterator = companyList.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}*/
	
	}

}
