package com.example.demo;

import java.util.List;
import java.util.Map;

public class Config {

	private String jobName;
	private int skiplines;
	private String type;
	private String delimiter;
	private int throttlelimit;
	private int chunksize;
	private String tableName;
	private List<String> columns;
	private Map<String, Validator>  validators;
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public int getSkiplines() {
		return skiplines;
	}
	public void setSkiplines(int skiplines) {
		this.skiplines = skiplines;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDelimiter() {
		return delimiter;
	}
	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}
	public int getThrottlelimit() {
		return throttlelimit;
	}
	public void setThrottlelimit(int throttlelimit) {
		this.throttlelimit = throttlelimit;
	}
	
	public int getChunksize() {
		return chunksize;
	}
	public void setChunksize(int chunksize) {
		this.chunksize = chunksize;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public List<String> getColumns() {
		return columns;
	}
	public void setColumns(List<String> columns) {
		this.columns = columns;
	}
	public Map<String, Validator> getValidators() {
		return validators;
	}
	public void setValidators(Map<String, Validator> validators) {
		this.validators = validators;
	}
	
	

}
